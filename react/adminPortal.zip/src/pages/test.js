import { FileWordFilled } from '@ant-design/icons'
import React, {Component} from 'react'
import PageLayout from '../layout/pageLayout';

export default class test extends Component{
    
    render(){
        return (
            <PageLayout>
                HELLO TESTING
            </PageLayout>
        );
    }
}
