import React from 'react';
import PageLayout from '../layout/pageLayout';

export default function dashboard(){
    return(
        <PageLayout>
        <h2> It can be anything but please show me Dashboard</h2>
        </PageLayout>
    );
}

